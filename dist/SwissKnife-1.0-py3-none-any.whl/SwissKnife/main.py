
def main():

    print("🇨🇭🔪")


